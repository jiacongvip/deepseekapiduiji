from fastapi import APIRouter, Body, Query, HTTPException, Request
from fastapi.responses import StreamingResponse
from src.service import chat_completion, delete_conversation
from src.model.response import CompletionResponse, DeleteResponse, ReferenceItem
from src.model.request import CompletionRequest, OpenAICompletionRequest
from src.pool.session_pool import DoubaoSession
import json
import time
import uuid
import asyncio
import random

router = APIRouter()


@router.post("/v1/chat/completions")
async def openai_completions(
    request: OpenAICompletionRequest = Body(),
    req: Request = None
):
    """
    OpenAI 兼容接口
    """
    try:
        # Extract session from Authorization header
        session_override = None
        if req:
            auth_header = req.headers.get("Authorization")
            if auth_header and auth_header.startswith("Bearer "):
                token = auth_header.split("Bearer ")[1].strip()
                if token.startswith("{") or token.startswith("["):
                    try:
                        data = json.loads(token)
                        if isinstance(data, list) and len(data) > 0:
                            session_data = random.choice(data)
                            session_override = DoubaoSession.from_dict(session_data)
                        elif isinstance(data, dict):
                            session_override = DoubaoSession.from_dict(data)
                            print(f"DEBUG: Session override successful with cookie: {session_override.cookie[:10]}...")
                    except Exception:
                        pass

        # 提取最后一条消息作为 prompt
        prompt = ""
        for msg in request.messages:
            if msg["role"] == "user":
                prompt = msg["content"]
        
        if not prompt:
            raise HTTPException(status_code=400, detail="No user message found")

        # Check for deep think in model name or request body
        use_deep_think = False
        if "deep" in request.model or getattr(request, "use_deep_think", False):
            use_deep_think = True

        # 调用原来的 chat_completion
        text, imgs, refs, conv_id, msg_id, sec_id = await chat_completion(
            prompt=prompt,
            guest=True, # 默认游客模式，除非 session_pool 支持注入
            conversation_id=None,
            section_id=None,
            attachments=[],
            use_auto_cot=False,
            use_deep_think=use_deep_think,
            session_override=session_override
        )

        # 格式化引用
        if refs:
            text += "\n\n**参考资料**:\n"
            for i, ref in enumerate(refs, 1):
                title = ref.get('title', '未知标题')
                url = ref.get('url', '#')
                site = ref.get('sitename', '')
                site_str = f" - {site}" if site else ""
                text += f"{i}. [{title}]({url}){site_str}\n"

        # 构造 OpenAI 格式响应
        response_id = f"chatcmpl-{uuid.uuid4()}"
        created = int(time.time())
        
        # 如果是流式
        if request.stream:
            async def stream_generator():
                # 使用外部作用域的 text 变量，避免重复调用 chat_completion
                # 模拟流式效果，将长文本拆分发送 (提升用户体验)
                chunk_size = 10 # 每次发送10个字符
                for i in range(0, len(text), chunk_size):
                    chunk_text = text[i:i+chunk_size]
                    chunk_data = {
                        "id": response_id,
                        "object": "chat.completion.chunk",
                        "created": created,
                        "model": request.model,
                        "choices": [{
                            "index": 0,
                            "delta": {"content": chunk_text},
                            "finish_reason": None
                        }]
                    }
                    yield f"data: {json.dumps(chunk_data)}\n\n"
                    # 稍微停顿一下，模拟打字机效果
                    await asyncio.sleep(0.02)
                
                # 发送结束标志
                chunk_end = {
                    "id": response_id,
                    "object": "chat.completion.chunk",
                    "created": created,
                    "model": request.model,
                    "choices": [{
                        "index": 0,
                        "delta": {},
                        "finish_reason": "stop"
                    }]
                }
                yield f"data: {json.dumps(chunk_end)}\n\n"
                yield "data: [DONE]\n\n"
            
            return StreamingResponse(stream_generator(), media_type="text/event-stream")

        return {
            "id": response_id,
            "object": "chat.completion",
            "created": created,
            "model": request.model,
            "choices": [{
                "index": 0,
                "message": {
                    "role": "assistant",
                    "content": text
                },
                "finish_reason": "stop"
            }],
            "usage": {
                "prompt_tokens": len(prompt),
                "completion_tokens": len(text),
                "total_tokens": len(prompt) + len(text)
            }
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/completions", response_model=CompletionResponse)
async def api_completions(completion: CompletionRequest = Body()):
    """
    豆包聊天补全接口(目前仅支持文字消息e和图片消息)
    1. 如果是新聊天 conversation_id, section_id**不填**
    2. 如果沿用之前的聊天, 则沿用**第一次对话**返回的 conversation_id 和 section_id, 会话池会使用之前的参数
    3. 目前如果使用未登录账号，那么不支持上下文
    """
    try:
        text, imgs, refs, conv_id, msg_id, sec_id = await chat_completion(
            prompt=completion.prompt,
            guest=completion.guest,
            conversation_id=completion.conversation_id,
            section_id=completion.section_id,
            attachments=completion.attachments,
            use_auto_cot=completion.use_auto_cot,
            use_deep_think=completion.use_deep_think
        )
        # 将字典转换为ReferenceItem对象
        references = [ReferenceItem(**ref) for ref in refs]
        
        return CompletionResponse(
            text=text, 
            img_urls=imgs, 
            references=references,
            conversation_id=conv_id, 
            messageg_id=msg_id, 
            section_id=sec_id
            )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))



@router.post("/delete", response_model=DeleteResponse)
async def api_delete(conversation_id: str = Query()):
    """
    删除聊天
    1. conversation_id 不存在也会提示成功
    2. 建议在聊天结束时都调用函数，避免创建过多对话
    """
    try:
        ok, msg = await delete_conversation(conversation_id)
        return DeleteResponse(
            ok=ok,
            msg=msg
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))