from fastapi import APIRouter
from .endpoints import chat
from .endpoints import file

router = APIRouter()

# 注册各个模块的路由
router.include_router(chat.router, tags=["聊天"]) # 移除 prefix="/chat" 以便支持根路径下的 /v1/chat/completions
router.include_router(file.router, prefix="/file", tags=["文件"])