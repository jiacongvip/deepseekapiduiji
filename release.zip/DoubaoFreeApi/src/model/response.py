from pydantic import BaseModel
from typing import Optional, List, Dict
import uuid


class ReferenceItem(BaseModel):
    """引用来源项"""
    title: str
    url: str
    snippet: Optional[str] = None
    index: Optional[int] = None
    sitename: Optional[str] = None
    publish_time: Optional[str] = None


class CompletionResponse(BaseModel):
    text: str
    img_urls: List[str]
    references: List[ReferenceItem] = []  # 引用的网站列表
    conversation_id: str
    messageg_id: str
    section_id: str
    
    
class UploadResponse(BaseModel):
    key: str
    name: str
    type: str
    file_review_state: int
    file_parse_state: int
    identifier: str
    option: Optional[Dict] = None
    md5: Optional[str] = None
    size: Optional[int] = None
    

class ImageResponse(BaseModel):
    key: str
    name: str
    option: Dict
    type: str = "vlm_image"
    file_review_state: int = 3
    file_parse_state: int = 3
    identifier: str = str(uuid.uuid1())


class FileResponse(BaseModel):
    key: str
    name: str
    md5: str
    size: int
    type: str = "file"
    file_review_state: int = 1
    file_parse_state: int = 3
    identifier: str = str(uuid.uuid1())
    

class DeleteResponse(BaseModel):
    ok: bool
    msg: str